package com.intel.realsense.android;

enum ConversionType {
    RGB,
    RGBA,
    DEPTH,
    IR;
}
